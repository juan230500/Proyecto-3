# Proyecto 3. Star Force Controller
Instituto Tecnológico de Costa Rica  
Ingeniería en Computadores.   
Proyecto 3 del curso de taller de programación  
2018, semestre 1

### Prerequisites

## Getting Started

### Problemas conocidos

## Autores
* Santiago Gamboa Ramírez  
santigr17@gmail.com  
2014092362  

### Version
1.0.0

